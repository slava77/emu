
                    DIM version 15.08 Release Notes

Notes 1 and 2 for Unix Users only
NOTE 1: In order to "make" DIM two environment variables should be set:
	OS = one of {HP-UX, AIX, OSF1, Solaris, SunOS, LynxOS, Linux}
	DIMDIR = the path name of DIM's top level directory
	The user should then go to DIM's top level directory and do:
	> source .setup
	> gmake all
	Or, if there is no support for C++ on the machine:
	> gmake CPP=no all

NOTE 2: The Name Server (Dns), DID, servers and clients (if running in 
	background) should be started whith the output redirected to a 
	logfile ex:
		Dns </dev/null >& dns.log &

NOTE 3: The Version Number service provided by servers is now set to 1508
	(version 15.08).

17/09/2004
Changes for version 15.0:
    - Changes for 64 bit machine (LP64 architecture) support
	- All DIM "tags" are now longs instead of ints this affects:
	    - Client callback parameters
	    - Server callback parameters
	    - Timer callback parameters
	  (The reason is: tags were very often user to pass pointers) 
	- DIM is now compiled with -fPIC by default on Linux
	- The byte swapping and structure padding was fixed.

14/10/2004
Changes for version 15.1:
    - Big Bug Fixed affecting the DIM_DNS for windows!!!!
	- Windows has an hidden default limit of the number of sockets
	  per process set to 64, only partially though, more sockets can
	  be created with no problem but they are silently masked out
          by the select call!
	- Anyway this limit is now set to 1024.
    - removed a few print statements.

28/10/2004
Changes for version 15.2:
    - Removed some C++ style comments which did not compile on Solaris.

02/11/2004
Changes for version 15.3:
    - Byte swapping was missing in one place when asking for stampped 
      services (noticed on Solaris)

11/11/2004
Changes for version 15.4:
    - Added two command line options to dim_send_command:
	dim_send_command <cmnd_name> [<data>] [-dns <dim_dns_node>] [-s]
        -dns allows setting the dim_dns_node, and -s means silent.      

03/12/2004
Changes for version 15.5:
    - Changed the bahaviour of the DNS "KILL_SERVERS" command. Now if the
      user declares a server exit_handler, the server will not exit (unless
      the user code explicilty exits) and will continue running fine, 
      otherwise the server exits as before.
    - The exit_handler now gets as parameter the error code that caused the
      exit request (so that the user can decide wether to exit or not) or 
      the code sent by the client, if the EXIT request came from a client. 
      As a result clients should not send exit codes lower than 0x100 in order 
      not to be confused with the internal error codes.
    - IMPORTANT NOTES:
      - The behaviour of the user error_handler() changed. Now the
	error_handler only gets called to report an error. If the user wants
	to modify the automatic exit behaviour he/she has to also declare an
	exit_handler. In previous versions if an error_handler was declared,
	the exit_handler was not necessary.
      - Also the Java version has changed since the ERROR codes changed.
   
07/12/2004
Changes for version 15.5-1:
    - Corrected a bug in include file dis.hxx introduced in v15r5

08/12/2004
Changes for version 15.6:
    - Included support for Scheduling policies and priorities between DIM
      threads by creating the calls:
	- dim_set_scheduler_class(int sched_class)
	- dim_get_scheduler_calss(int *sched_class)
	- dim_set_priority(int dim_thread, int priority)
	- dim_get_priority(int dim_thread, int priority)

      These calls are only implemented on Linux and Windows and they have 
      different behaviour on the two platforms:
	- dim_set_scheduler_class(int sched_class)
	On Windows:
	  sched_class is the process's priority class:
		-1 = IDLE_PRIORITY_CLASS
		 0 = NORMAL_PRIORITY_CLASS
		 1 = HIGH_PRIORITY_CLASS
		 2 = REALTIME_PRIORITY_CLASS
	On Linux:
	  sched_class is the process's schedule policy:
		 0 = SCHED_OTHER
		 1 = SCHED_FIFO
		 2 = SCHED_RR
	  All threads in the process will be set to this sched_class
	
	- dim_set_priority(int dim_thread, int priority)
	  where dim_thread : 1 - Main thread, 2 - IO thread, 3 - Timer thread
	On Windows:
	  priority is the thread's relative priority:
		-3 = THREAD_PRIORITY_IDLE
		-2 = THREAD_PRIORITY_LOWEST
		-1 = THREAD_PRIORITY_BELOW_NORMAL
		 0 = THREAD_PRIORITY_NORMAL
		 1 = THREAD_PRIORITY_ABOVE_NORMAL
		 2 = THREAD_PRIORITY_HIGHEST
		 3 = THREAD_PRIORITY_TIME_CRITICAL

	On Linux:
	  priority is the thread's absolute priority:
		 0 	for SCHED_OTHER
		 1 - 99 for SCHED_FIFO or SCHED_RR

03/02/2005
Changes for version 15.7:
    - Fixed a bug that made DIM servers crash when unplugging for a short time the
      network cable.
    - Linux executables and libraries are now compiled on Linux SLC3 with gcc 3.2.3
    - Contains a new version of the DIM Tree Browser for WIndows. 

02/03/2005
Changes for version 15.8:
    - Contains again a new version of the DIM Tree Browser for WIndows, now allows
      to display structures correctly (Thanks to Serguei Sergueev). 
    - DIM used old style predefined macros, for example linux instead of __linux__.
      So it didn't compile when users used gcc/g++ -ansi -pedantic. Fixed.
    - A check is now made on the length of a DIM service name. The service is 
      discarded if the name is longer then 131 characters.

Please check the Manual for more information at:
    http://www.cern.ch/dim
