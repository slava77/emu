#include <assert.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#ifdef __VMS
#include <starlet.h>
#endif

#define DIMLIB
#include <dim_core.hxx>
#include <dim.hxx>

int DimCore::inCallback = 0;

extern "C" {
static void timer_user_routine(void *tp)
{
	DimTimer *t = (DimTimer *)tp;
	DimCore::inCallback = 1;
	t->firedFlag = 1;
	t->runningFlag = 0;
	t->timerHandler();
	DimCore::inCallback = 0;
}
}

void DimTimer::start(int time)
{
	runningFlag = 1;
	firedFlag = 0;
	dtq_start_timer(time, timer_user_routine, this);
}

int DimTimer::stop() 
{
	firedFlag = 0;
	runningFlag = 0;
	return dtq_stop_timer(this);
}

DimTimer::DimTimer() 
{ 
	firedFlag = 0;
	runningFlag = 0; 
}
	
DimTimer::DimTimer(int time)
{ 
	start(time);
}

DimTimer::~DimTimer()
{
	if(runningFlag)
		stop();
}
