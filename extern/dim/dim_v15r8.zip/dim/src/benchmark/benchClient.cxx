#include <dic.hxx>

#define TEST_TIME 10

class Service : public DimInfo
{
  int nReceived;
  int msgSize;

	void infoHandler()
	{
	  msgSize = getSize();
	  nReceived++;
	}
public :
	Service(char *name) : DimInfo(name,"--") {nReceived = 0;}
	int getNServices() {return nReceived;}
	int getMsgSize() {return msgSize;}
	void clearNServices() {nReceived = 0;}
};


int main(int argc, char *argv[])
{
	int i, n, msgSize, nServices = 0;
	Service **services;
	float mps,tpm;
	DimBrowser br;
	char *name, *format;

	br.getServices("BENCH_SERVICE_*");

	while(br.getNextService(name, format)!= 0)
	{
//		cout << name << " " << format << endl;
		nServices++;
	}
	services = new Service*[nServices];
	i = 0;
	while(br.getNextService(name, format)!= 0)
	{
	  services[i++] = new Service(name);
	}
	sleep(5);
	for(i = 0; i < nServices; i++)
	  services[i]->clearNServices();
	sleep(TEST_TIME);
	n = 0;
	for(i = 0; i < nServices; i++)
	{
	  n += services[i]->getNServices();
	}
	msgSize = services[0]->getMsgSize();
	mps = n/TEST_TIME;
	cout << "Messages/s = " << mps << endl;
	tpm = 1/(float)mps*1000;
	cout << "Time(ms)/message = " << tpm << endl;
	cout << "Throughput (Kb/s) = " << mps*msgSize/1024 << endl;
	while(1)
		pause();
}
