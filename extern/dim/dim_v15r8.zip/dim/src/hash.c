#define DIMLIB
#include <dim.h>

/*
 * Hash function
 */

int HashFunction(name, max)
char	*name;
int	max;
{
    register int code = 0;	/* hash code value */

	while(*name)
	{
		code += *name++;
	}
	return (code % max);
}

